<div id="footer"><!-- Footer -->
              <div class="footer-widget">
                  <div class="container">
                      <div class="row">
                          <div class="col-md-3">
                              <div class="text-widget">
                                  <div class="wid-title">Welcome to</div>
                                  <img src="images/logo-white.png" alt="ft-logo">
                                  <p>
                                      Believe isCommerce WordPress theme. It has<br/>everything you need to start selling today! <a href="">Get this theme on ThemeForest!</a>
                                  </p>
                                  <ul class="ft-soc clearfix">
                                      <li><a href=""><i class="fa fa-facebook-square"></i></a></li>
                                      <li><a href=""><i class="fa fa-twitter"></i></a></li>
                                      <li><a href=""><i class="fa fa-google-plus-square"></i></a></li>
                                      <li><a href=""><i class="fa fa-instagram"></i></a></li>
                                      <li><a href=""><i class="fa fa-pinterest"></i></a></li>
                                  </ul>
                                  <div class="clearfix"></div>
                              </div>
                          </div>
                          <div class="col-md-2">
                              <div class="quick-links">
                                  <div class="wid-title">Quick Links</div>
                                  <ul>
                                      <li><a href="<?php echo e(url('home')); ?>">Home</a></li>
                                      <li><a href="<?php echo e(url('about-us')); ?>">About US</a></li>
                                      <li><a href="<?php echo e(url('contact-us')); ?>">contact US</a></li>
                                      <li><a href="<?php echo e(url('deals')); ?>">deals</a></li>
                                      <li><a href="<?php echo e(url('blog')); ?>">blog</a></li>
                                      <li><a href="<?php echo e(url('helps')); ?>">help</a></li>
                                  </ul>
                              </div>
                          </div>
                          <div class="col-md-2">
                              <div class="term">
                                  <div class="wid-title">&nbsp;</div>
                                  <p>
                                      <a href="<?php echo e(url('terms-and-condition')); ?>">Tearms & condition</a><br/>
                                      <a href="<?php echo e(url('faqs')); ?>">FAQs</a><br/>
                                      <a href="<?php echo e(url('privay-policy')); ?>">Privacy Policy</a><br/>
                                      <a href="<?php echo e(url('legal-desclainmer')); ?>">Legal Desclaimer</a><br/>
                                  </p>
                              </div>
                          </div>
                          <div class="col-md-2">
                              <div class="quick-links">
                                  <div class="wid-title">My Account</div>
                                  
                                  <ul>
                                      <li><a href="<?php echo e(url('my-account')); ?>">My Account</a></li>
                                      <li><a href="<?php echo e(url('personal-information')); ?>">Personal Information</a></li>
                                      <li><a href="<?php echo e(url('address')); ?>">Addresses</a></li>
                                      <li><a href="<?php echo e(url('orders')); ?>">Orders</a></li>
                                      <li><a href="<?php echo e(url('wish-list')); ?>">Wishlist</a></li>
                                      <li><a href="<?php echo e(url('orders')); ?>">track order</a></li>
                                  </ul>
                              </div>
                          </div>
                          <div class="col-md-3">
                              <div class="subscribe">
                                  <div class="wid-title">Subscribe for OFFERS & UPDATES</div>
                                  <p>
                                      Enter your email and we'll send you a coupon
                                      with 10% off your next order. Add any text here
                                  </p>
                                  <form>
                                      <div class="form-group">
                                          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                                      </div>
                                      <button type="submit" class="btn btn-default">Subscribe Now</button>
                                  </form>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="footer-text">
                  <div class="container">
                      <p>Copyright 2018. Designed and Developed by <a href="https://bootstrapmart.com/">BootstrapMart </a> &amp; Distributed by <a href="https://themewagon.com/">ThemeWagon</a></p>
                  </div>
              </div>
          </div><!-- Footer -->
      </div> <!-- wrapper -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/library.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.raty.js"></script>
    <script src="js/ui.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.selectbox-0.2.js"></script>
    <script src="js/theme-script.js"></script>
  </body>
</html><?php /**PATH C:\xampp\xampp\htdocs\jk-pro\footflex\resources\views/inc/footer.blade.php ENDPATH**/ ?>